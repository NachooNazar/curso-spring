package com.rest.apirestspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestSpringbootApplication.class, args);
	}

}
